import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.connect("10.0.0.7", 2020)

print(f"Client connected on server port 2020... ")

sock.send("Hello server!")