import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.bind(("127.0.0.1", 2020))

s.listen(5)
print("Server is listening on port 2020...")

client_socket,client_address = s.accept()
print(f"Connection established with {client_address}")

while True:
 data = client_socket.recv(1024)
 client_socket.send(data)
 print(f"received data from client: {data.decode()}")
 