import time
import requests

def check_analysis(analysis_id: str):
    url = f"https://www.virustotal.com/api/v3/analyses/{analysis_id}"
    headers = {"x-apikey": API_KEY}

    print(f"Waiting for analysis results ({analysis_id})...")

    while True:
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print(f"Error checking status: {response.status_code}")
            return

        res_json = response.json()
        attributes = res_json.get("data", {}).get("attributes", {})
        status = attributes.get("status")

        if status == "completed":
            stats = attributes.get("stats", {})
            
            print("\n--- Analysis Results ---")
            print(f"Malicious: {stats.get('malicious', 0)}")
            print(f"Suspicious: {stats.get('suspicious', 0)}")
            print(f"Harmless: {stats.get('harmless', 0)}")
            print(f"Undetected: {stats.get('undetected', 0)}")
            break

        print("Scan in progress... waiting 5 seconds.")
        time.sleep(5)