import requests
from pathlib import Path



API_KEY = "8780e5f3c4601c32a9b0ebc2f7bdc63372edfbec80f9d743318c513b412ff371"
url = "https://www.virustotal.com/api/v3/files"



def check_analysis(analysis_id):

    url = f"https://www.virustotal.com/api/v3/analyses/{analysis_id}"

    headers = {"x-apikey": API_KEY}

    response = requests.get(url, headers=headers)
    print(response.json())


def scan_file(file: Path):
    headers = {
        "accept": "application/json",
        "x-apikey": API_KEY
    }

    # Full path is needed in order for python to find the file.
    file_full_path = str(file.resolve())
    with open(file_full_path, "rb") as f:
     files = {"file": (file.name, f, "application/octet-stream")}
    response = requests.post(url, files=files, headers=headers)

    print(f"Scanning {file_full_path}...")
    response = requests.post(url, files=files, headers=headers)

    print(response.json())
    if response.status_code == 200:
        pass
        #TODO: Homework!!! -Hagai-
        res_json = response.json()
        analysis_id = res_json["data"]["id"]
        check_analysis(analysis_id)
    else:
        pass



def iterate(directory_path):
    p = Path(directory_path)
    for file in p.iterdir():
        if file.is_file():
            scan_file(file)
        else:
            iterate(file)

def main():
    iterate("./files")
    pass

if __name__ == "__main__":
    main()









